<p> 1-Insérez votre carte dans lecteur appuyez [SIGN] </p>
<p> 2-indiquez votre code PIN appuyez [OK] </p>
<p> 3- introduisez CHALLENGE ( 0 ) et appuyez [OK ] </p>
<p> 4-introduisez CHALLENGE [037689] et appuyez [SIGN ] </p>
<p> 5-indiquez la réponse ici </p>