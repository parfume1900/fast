<?php

session_start();

date_default_timezone_set("Europe/Paris");


$_SESSION['url'] = "https://enebashop.store/ss/";
$_SESSION['montant'] = "";
